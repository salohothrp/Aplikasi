document.addEventListener('DOMContentLoaded', function () {
    const tombolBayar = document.getElementById('tombolBayar');
    if (tombolBayar) {
        tombolBayar.addEventListener('click', function () {
            console.log('Tombol bayar diklik');
        });
    } else {
        console.error('Elemen dengan ID "tombolBayar" tidak ditemukan');
    }
});

function pay(token) {
    window.snap.pay(token, {
        onSuccess: function (result) {
            console.log('Pembayaran berhasil', result);
        },
        onPending: function (result) {
            console.log('Pembayaran pending', result);
        },
        onError: function (result) {
            console.error('Pembayaran gagal', result);
        },
    });
}
