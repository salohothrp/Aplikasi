function toggleDetails(id) {
    const content =document.getElementById(id);
    content.style.display = content.style.display === 'none' || content.style.display === '' ? 'block' : 'none';
}

function confirmPrint() {
    if (confirm('Apakah Anda yakin ingin mencetak transaksi ini?')) {
        window.print();
    }
}



function kembaliBeranda() {
    window.location.href = '../mahasiswa/header_mahasiswa.php';
}