// const container=document.querySelector('.container');
// const Loginlink=document.querySelector('.SignInLink');
// const Registerlink=document.querySelector('.SignUpLink');
// Registerlink.addEventListener('click',()=>{
//     container.classList.add('active');
// })
// Loginlink.addEventListener('click',()=>{
//     container.classList.add('active');
// })

const container = document.querySelector('.container');
const Loginlink = document.querySelector('.SignInLink');
const Registerlink = document.querySelector('.SignUpLink');

// Pastikan elemen ada sebelum menambahkan event listener
if (Registerlink) {
    Registerlink.addEventListener('click', () => {
        container.classList.add('active');
    });
}

if (Loginlink) {
    Loginlink.addEventListener('click', () => {
        container.classList.remove('active');
    });
}


