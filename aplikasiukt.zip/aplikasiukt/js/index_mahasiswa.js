document.addEventListener('DOMContentLoaded', function() {
  // Toggle sidebar
  const body = document.querySelector('body');
  const toggleBtn = document.querySelector('.toggle-btn');
  
  if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
          body.classList.toggle('active');
      });
  }

  // Profile dropdown
  const userProfileBtn = document.getElementById('userProfileBtn');
  const profileDropdown = document.getElementById('profileDropdown');

  if (userProfileBtn && profileDropdown) {
      let isDropdownOpen = false;

      // Toggle dropdown saat user profile diklik
      userProfileBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          isDropdownOpen = !isDropdownOpen;
          profileDropdown.style.display = isDropdownOpen ? 'block' : 'none';
      });

      // Tutup dropdown saat mengklik di luar area dropdown
      document.addEventListener('click', (e) => {
          if (!userProfileBtn.contains(e.target) && isDropdownOpen) {
              profileDropdown.style.display = 'none';
              isDropdownOpen = false;
          }
      });
  }
});

function showContent(contentType) {
    // Sembunyikan semua konten
    document.querySelectorAll('.content-wrapper').forEach(wrapper => {
        wrapper.classList.remove('active'); // Hilangkan class active
    });

    // Tampilkan konten yang sesuai
    const contentWrapper = document.getElementById(contentType + '-content');
    if (contentWrapper) {
        contentWrapper.classList.add('active'); // Tambahkan class active
    }

    // Update active state pada sidebar
    document.querySelectorAll('.sidebar-links .link').forEach(link => {
        link.classList.remove('active'); // Hilangkan active pada sidebar link
    });

    // Tambahkan class active pada link yang diklik
    event.currentTarget.classList.add('active');
}



// <!-- payment midtrans -->
// <!-- Payment Method Modal -->

function payButton(idPembayaran, nim, jumlah, nama, fakultas, angkatan) {
    console.log('Memulai proses pembayaran...');

    fetch('/aplikasiukt/midtrans/bayar_midtrans.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            idPembayaran: idPembayaran,
            nim: nim,
            jumlah: jumlah,
            nama: nama,
            fakultas: fakultas,
            angkatan: angkatan
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.token) {
            window.snap.pay(data.token, {
                onSuccess: function(result) {
                    // Call update status API
                    fetch('update_payment_status.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            order_id: result.order_id,
                            id_pembayaran: idPembayaran,
                            bank: result.va_numbers
                                ? result.va_numbers[0].bank
                                : (result.payment_type === 'echannel' ? 'Mandiri' : 
                                   result.payment_type === 'bank_transfer' && result.permata_va_number ? 'Permata' :
                                   result.payment_type === 'bank_transfer' && result.bri_va_number ? 'BRI' :
                                   'Tidak Diketahui')
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Pembayaran Berhasil!',
                                text: 'Status pembayaran telah diperbarui',
                                showConfirmButton: true
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    location.reload();
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: 'Gagal mengupdate status pembayaran'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Terjadi kesalahan sistem'
                        });
                    });
                },
                
                onPending: function(result) {
                    Swal.fire({
                        icon: 'info',
                        title: 'Pembayaran Pending',
                        text: 'Silakan selesaikan pembayaran Anda'
                    });
                },
                onError: function(result) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Pembayaran Gagal',
                        text: 'Silakan coba lagi'
                    });
                },
                onClose: function() {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Pembayaran Dibatalkan',
                        text: 'Anda menutup popup tanpa menyelesaikan pembayaran'
                    });
                }
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Terjadi kesalahan: Token pembayaran tidak ditemukan'
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Terjadi kesalahan saat memproses pembayaran'
        });
    });
}
