<?php
// Di awal file bayar_midtrans.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data');
    }

    // Validasi input
    if (!isset($input['idPembayaran']) || !isset($input['nim']) || !isset($input['jumlah']) || !isset($input['nama'])) {
        throw new Exception('Missing required fields');
    }

    require_once __DIR__ . '/midtrans-php-master/Midtrans.php';

    \Midtrans\Config::$serverKey = 'SB-Mid-server-Go3hUayddVcx8gj2VqyxeH31';
    \Midtrans\Config::$isProduction = false;
    \Midtrans\Config::$isSanitized = true;
    \Midtrans\Config::$is3ds = true;

    $orderId = 'ORDER-' . time() . '-' . uniqid();

    // Detail transaksi
    $transaction_details = array(
        'order_id' => $orderId,
        'gross_amount' => (int)$input['jumlah']
    );

    // Detail item
    $item_details = array(
        array(
            'id' => $input['idPembayaran'],
            'price' => (int)$input['jumlah'],
            'quantity' => 1,
            'name' => 'Pembayaran UKT',
        )
    );

    // Detail pelanggan dengan format yang diminta
    $customer_details = array(
        'first_name' => "Nama             : " . $input['nama'] . "\n" .
                       "NIM                : " . $input['nim'] . "\n" .
                       "Fakultas         : " . $input['fakultas'] . "\n" .
                       "Angkatan       : " . $input['angkatan'],
    );

    // Gabungkan semua detail
    $transaction_data = array(
        'transaction_details' => $transaction_details,
        'item_details' => $item_details,
        'customer_details' => $customer_details
    );

    $snapToken = \Midtrans\Snap::getSnapToken($transaction_data);
    echo json_encode(['token' => $snapToken]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
    error_log("Error in bayar_midtrans.php: " . $e->getMessage());
}
?>