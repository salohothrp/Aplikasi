<?php  
require_once './koneksi.php'; // Koneksi database  

// Ambil data dari notifikasi  
$rawInput = file_get_contents('php://input');  
$input = json_decode($rawInput, true);  

// Validasi dan ambil data yang diperlukan  
$orderId = $input['order_id'];  
$status = $input['transaction_status'];  
$nobayar = $input['transaction_id']; // ID pembayaran dari Midtrans  

if ($status === 'settlement') {  
    // Update status pembayaran di database menjadi LUNAS  
    $update_query = "UPDATE pembayaran SET nobayar = ?, ket = 'LUNAS' WHERE id_pembayaran = ?";  
    $stmt = $conn->prepare($update_query);  
    $stmt->bind_param("si", $nobayar, $orderId); // orderId adalah id_pembayaran  
    $stmt->execute();  
}  
?>