function pay(token) {
    window.snap.pay(token, {
        onSuccess: function (result) {
            console.log('Pembayaran berhasil', result);
        },
        onPending: function (result) {
            console.log('Pembayaran pending', result);
        },
        onError: function (result) {
            console.error('Pembayaran gagal', result);
        },
    });
}
