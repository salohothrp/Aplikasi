<?php
session_start();

// Pastikan user telah login dan role adalah mahasiswa
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'mahasiswa') {
    header('Location: loginauth.php');
    exit();
}

// Sertakan file koneksi
include '../koneksi.php';

// Ambil NIM dari session
$nim = $_SESSION['nim'];

// Query untuk mengambil data mahasiswa
$query = "SELECT * FROM mahasiswa WHERE nim = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $nim);
$stmt->execute();
$result = $stmt->get_result();

// Validasi jika data mahasiswa tidak ditemukan
if ($result->num_rows === 0) {
    echo "Data mahasiswa tidak ditemukan.";
    exit();
}

$mahasiswa = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Mahasiswa</title>
</head>

<body>
    <h1>Profil Mahasiswa</h1>
    <p><strong>Nama:</strong> <?php echo htmlspecialchars($mahasiswa['nama']); ?></p>
    <p><strong>NIM:</strong> <?php echo htmlspecialchars($mahasiswa['nim']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($mahasiswa['email']); ?></p>
    <a href="mahasiswa_dasboard.php">Kembali ke Dashboard</a>
</body>

</html>