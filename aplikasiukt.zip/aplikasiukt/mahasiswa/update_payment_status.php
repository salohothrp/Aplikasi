<?php
session_start();
header('Content-Type: application/json');

// Konfigurasi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'webpembayaranukt';

// Koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die(json_encode([
        'status' => 'error',
        'message' => 'Koneksi database gagal: ' . mysqli_connect_error()
    ]));
}

function getTransactionDetails($conn, $order_id) {
    $query = "SELECT id_pembayaran, nobayar, ket, jumlah, tglbayar FROM pembayaran WHERE nobayar = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $order_id);
    $stmt->execute();
    return $stmt->get_result();
}


// Terima data dari request
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['order_id']) && isset($data['id_pembayaran'])) {
    $order_id = $data['order_id'];
    $id_pembayaran = $data['id_pembayaran'];

    // Tentukan nama bank atau metode pembayaran
    $bank = 'VA Tidak Diketahui'; // Default value
    if (isset($data['bank'])) {
        $bank = $data['bank'];
    } elseif (isset($data['payment_type'])) {
        switch ($data['payment_type']) {
            case 'echannel':
                $bank = 'Mandiri';
                break;
            case 'bank_transfer':
                if (isset($data['permata_va_number'])) {
                    $bank = 'Permata';
                } elseif (isset($data['bri_va_number'])) {
                    $bank = 'BRI';
                } else {
                    $bank = 'Bank Transfer Lainnya';
                }
                break;
            case 'credit_card':
                $bank = 'Kartu Kredit';
                break;
            default:
                $bank = 'Metode Tidak Diketahui';
        }
    }
    
    // Update status pembayaran
    $query = "UPDATE pembayaran SET 
              ket = 'LUNAS',
              nobayar = ?,
              tglbayar = NOW()
              WHERE id_pembayaran = ?";
              
    $stmt = $conn->prepare($query);
    $stmt->bind_param('si', $order_id, $id_pembayaran);
    
    if ($stmt->execute()) {
        // Insert ke payment_midtrans
        $insert_payment = "INSERT INTO payment_midtrans (id_pembayaran, bank, order_id) 
                         VALUES (?, ?, ?)";
        $stmt_insert = $conn->prepare($insert_payment);
        $stmt_insert->bind_param('iss', $id_pembayaran, $bank, $order_id);
        $stmt_insert->execute();
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Status pembayaran berhasil diupdate'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal mengupdate status pembayaran'
        ]);
    }
}

$conn->close();

?>