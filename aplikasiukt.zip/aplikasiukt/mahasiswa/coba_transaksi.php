<?php 
session_start();
include 'koneksi.php';

if(isset($_GET['act'])) {
    if($_GET['act'] == 'bayar') {
        $id_pembayaran = $_GET['id'];
        $nim = $_GET['nim'];

        // Verify if the logged-in student matches the NIM
        if(!isset($_SESSION['nim']) || $_SESSION['nim'] != $nim) {
            echo "<script>
            alert('Akses ditolak. Anda hanya dapat mengakses pembayaran untuk akun Anda sendiri.');
            document.location = 'mahasiswa_dasboard.php';
            </script>";
            exit;
        }

        // tanggal bayar
        $tglbayar = date('Y-m-d');
        $nobayar = date('dmYHisis');

        // Update pembayaran ke status pending
        // Mahasiswa hanya bisa mengubah status ke PENDING, menunggu konfirmasi admin
        $byr = mysqli_query($conn, "UPDATE pembayaran SET 
            nobayar = '$nobayar',
            tglbayar = '$tglbayar',
            ket = 'PENDING'
            WHERE id_pembayaran = '$id_pembayaran' 
            AND nim = '$nim'"); // Additional security check

        if($byr) {
            header('location: pembayaran_mahasiswa.php?nim=' . $nim);
        } else {
            echo "<script>
            alert('Gagal memproses pembayaran. Silakan coba lagi.');
            document.location = 'pembayaran_mahasiswa.php?nim=" . $nim . "';
            </script>";
        }
    }
    else if($_GET['act'] == 'batal') {
        $id_pembayaran = $_GET['id'];
        $nim = $_GET['nim'];

        // Verify if the logged-in student matches the NIM
        if(!isset($_SESSION['nim']) || $_SESSION['nim'] != $nim) {
            echo "<script>
            alert('Akses ditolak. Anda hanya dapat mengakses pembayaran untuk akun Anda sendiri.');
            document.location = 'mahasiswa_dasboard.php';
            </script>";
            exit;
        }

        // Cek status pembayaran sebelum membatalkan
        $check_status = mysqli_query($conn, "SELECT ket FROM pembayaran 
            WHERE id_pembayaran = '$id_pembayaran' 
            AND nim = '$nim'");
        $status = mysqli_fetch_assoc($check_status);

        // Mahasiswa hanya bisa membatalkan pembayaran dengan status PENDING
        if($status['ket'] == 'PENDING') {
            $batal = mysqli_query($conn, "UPDATE pembayaran SET 
                nobayar = NULL,
                tglbayar = NULL,
                ket = NULL
                WHERE id_pembayaran = '$id_pembayaran' 
                AND nim = '$nim'"); // Additional security check

            if($batal) {
                header('location: pembayaran_mahasiswa.php?nim=' . $nim);
            } else {
                echo "<script>
                alert('Gagal membatalkan pembayaran. Silakan coba lagi.');
                document.location = 'pembayaran_mahasiswa.php?nim=" . $nim . "';
                </script>";
            }
        } else {
            echo "<script>
            alert('Pembayaran hanya dapat dibatalkan jika statusnya masih PENDING.');
            document.location = 'pembayaran_mahasiswa.php?nim=" . $nim . "';
            </script>";
        }
    }
}
?>



<!-- --------------------------------------------------------------view_transaksi -->


<?php
session_start();

// Pastikan user telah login dan role adalah mahasiswa
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'mahasiswa') {
    header('Location: loginauth.php');
    exit();
}

// Sertakan file koneksi
include '../koneksi.php';

// Ambil data dari session
$nim = $_SESSION['nim'];

// Ambil bulan dan tahun saat ini
$bulan = date('m'); // Format: 01, 02, ...
$tahun = date('Y'); // Tahun saat ini

// Query untuk mendapatkan informasi mahasiswa berdasarkan NIM
$query_mahasiswa = "SELECT m.*, a.nama_angkatan, j.nama_jurusan, k.nama_kelas 
                    FROM mahasiswa m
                    JOIN angkatan a ON m.id_angkatan = a.id_angkatan
                    JOIN jurusan j ON m.id_jurusan = j.id_jurusan
                    JOIN kelas k ON m.id_kelas = k.id_kelas
                    WHERE m.nim = ?";

$stmt_mahasiswa = $conn->prepare($query_mahasiswa);
$stmt_mahasiswa->bind_param('s', $nim);
$stmt_mahasiswa->execute();
$result_mahasiswa = $stmt_mahasiswa->get_result();

if ($result_mahasiswa->num_rows === 0) {
    echo "<p>Data mahasiswa dengan NIM <b>$nim</b> tidak ditemukan.</p>";
    exit();
}

$mahasiswa = $result_mahasiswa->fetch_assoc();
$id_mahasiswa = $mahasiswa['id_mahasiswa'];

// Query untuk mendapatkan data pembayaran berdasarkan id_mahasiswa dan filter per bulan
$query_pembayaran = "SELECT * FROM pembayaran 
                     WHERE id_mahasiswa = ? 
                     AND MONTH(jatuhtempo) = ? AND YEAR(jatuhtempo) = ?
                     ORDER BY jatuhtempo ASC";

$stmt_pembayaran = $conn->prepare($query_pembayaran);
$stmt_pembayaran->bind_param('iss', $id_mahasiswa, $bulan, $tahun);
$stmt_pembayaran->execute();
$result_pembayaran = $stmt_pembayaran->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi Mahasiswa</title>
    <link rel="stylesheet" href="path-to-your-css-styles.css">
</head>

<body>
    <h1>Transaksi Pembayaran Bulan <?php echo date('F Y'); ?></h1>

    <!-- Panel Biodata Mahasiswa -->
    <div class="biodata">
        <h2>Biodata Mahasiswa</h2>
        <table border="1">
            <tr>
                <td>NIM</td>
                <td><?php echo htmlspecialchars($mahasiswa['nim']); ?></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><?php echo htmlspecialchars($mahasiswa['nama']); ?></td>
            </tr>
            <tr>
                <td>Fakultas</td>
                <td><?php echo htmlspecialchars($mahasiswa['nama_kelas']); ?></td>
            </tr>
            <tr>
                <td>Tahun Ajaran</td>
                <td><?php echo htmlspecialchars($mahasiswa['nama_angkatan']); ?></td>
            </tr>
        </table>
    </div>

    <!-- Panel Transaksi -->
    <div class="transaksi">
        <h2>Detail Transaksi Pembayaran</h2>
        <?php if ($result_pembayaran->num_rows === 0): ?>
        <p>Belum ada transaksi yang tercatat untuk bulan ini.</p>
        <?php else: ?>
        <table border="1">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Bulan</th>
                    <th>Jatuh Tempo</th>
                    <th>No Bayar</th>
                    <th>Tanggal Bayar</th>
                    <th>Jumlah</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $no = 1;
                    while ($row = $result_pembayaran->fetch_assoc()): 
                        $tanggal_bayar = $row['tglbayar'] ? date('d-m-Y', strtotime($row['tglbayar'])) : '-';
                        $jumlah_formatted = number_format($row['jumlah'], 0, ',', '.');
                    ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['bulan']); ?></td>
                    <td><?php echo date('d-m-Y', strtotime($row['jatuhtempo'])); ?></td>
                    <td><?php echo $row['nobayar'] ?: '-'; ?></td>
                    <td><?php echo $tanggal_bayar; ?></td>
                    <td>Rp <?php echo $jumlah_formatted; ?></td>
                    <td><?php echo $row['ket'] ?: '-'; ?></td>
                    <td>
                        <?php if (empty($row['nobayar'])): ?>
                        <a class="btn btn-primary btn-sm"
                            href="proses_transaksi_mahasiswa.php?act=bayar&id=<?php echo $row['id_pembayaran']; ?>">Bayar</a>
                        <?php else: ?>
                        <a class="btn btn-success btn-sm"
                            href="riwayat_transaksi.php?id_mahasiswa=<?php echo $id_mahasiswa; ?>">Riwayat Transaksi</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <a href="mahasiswa_dasboard.php">Kembali ke Dashboard</a>
</body>

</html>