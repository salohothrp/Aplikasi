<?php 
session_start();
include 'koneksi.php';

if(isset($_GET['act']) ) {
	if($_GET['act']=='bayar') {
		$id_pembayaran = $_GET['id'];
		$nim   = $_GET['nim'];

        if(isset($_SESSION['nama_mahasiswa'])) {
            $nama_mahasiswa = $_SESSION['nama_mahasiswa'];
        }else{
            echo "<script>
            alert ('Session Admin Tidak Temukan. Silahkan Login ULang.');
            document.location = 'loginauth.php';
            </script>";
            exit;
        }

		// tanggal bayar
		$tglbayar = date('Y-m-d');
		$nobayar = date('dmYHisis');
        // $id_admin = $_SESSION['id_admin'];

		// id admin
		// $admin = $_SESSION['id'];

        // update pembayaran ke status lunas
		$byr = mysqli_query($conn,"UPDATE pembayaran SET 
			nobayar = '$nobayar',
			tglbayar = '$tglbayar',
			ket = 'LUNAS',
			id_admin = '$id_admin' 
			WHERE id_pembayaran = '$id_pembayaran'");

		if ($byr) {	
			header('location: pembayaran.php?nim=' .$nim);
		}else {
			echo "<script>
                alert('Gagal melakukan pembayaran. Silakan coba lagi.');
                document.location = 'pembayaran.php?nim=' . $nim;
                </script>";

		}
		
	}
}
?>