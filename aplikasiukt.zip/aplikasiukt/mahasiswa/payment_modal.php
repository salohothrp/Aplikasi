<!-- Loading indicator -->
<div id="loadingIndicator" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
    <div class="bg-white p-4 rounded">
        <p>Memproses pembayaran...</p>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="hidden fixed inset-0 bg-black bg-opacity-50">
    <div class="bg-white p-6 rounded-lg max-w-md mx-auto mt-20">
        <div id="paymentInstructions"></div>
        <button onclick="this.parentElement.parentElement.classList.add('hidden')"
            class="mt-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">
            Tutup
        </button>
    </div>
</div>

<!-- Success Modal -->
<div id="successModal" class="hidden fixed inset-0 bg-black bg-opacity-50">
    <div class="bg-white p-6 rounded-lg max-w-md mx-auto mt-20">
        <h3 class="text-lg font-bold mb-4">Pembayaran Berhasil!</h3>
        <p>Pembayaran Anda telah berhasil diproses.</p>
        <div class="mt-4 flex justify-between">
            <a href="riwayat_transaksi.php" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                Lihat Riwayat Transaksi
            </a>
            <button onclick="this.parentElement.parentElement.parentElement.classList.add('hidden')"
                class="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">
                Tutup
            </button>
        </div>
    </div>
</div>