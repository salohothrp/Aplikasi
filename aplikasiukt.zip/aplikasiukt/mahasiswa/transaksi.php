<?php
session_start();

// Periksa apakah user sudah login
if (!isset($_SESSION['nim']) || !isset($_SESSION['nama_mahasiswa'])) {
    session_destroy();
    header('location: loginauth.php');
    exit();
}

// Konfigurasi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'webpembayaranukt';

// Koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Ambil data mahasiswa
$nim = $_SESSION['nim'];
// Query untuk mengambil data mahasiswa berdasarkan NIM
// Query untuk mendapatkan informasi mahasiswa berdasarkan NIM
$query_mahasiswa = "SELECT m.*, a.nama_angkatan, j.nama_jurusan, k.nama_kelas 
                    FROM mahasiswa m
                    JOIN angkatan a ON m.id_angkatan = a.id_angkatan
                    JOIN jurusan j ON m.id_jurusan = j.id_jurusan
                    JOIN kelas k ON m.id_kelas = k.id_kelas
                    WHERE m.nim = ?";
$stmt_mahasiswa = $conn->prepare($query_mahasiswa);
if (!$stmt_mahasiswa) {
    die("Query gagal: " . $conn->error);
}
$stmt_mahasiswa->bind_param('s', $nim);
$stmt_mahasiswa->execute();
$result_mahasiswa = $stmt_mahasiswa->get_result();

if ($result_mahasiswa->num_rows === 0) {
    echo "<p>Data mahasiswa dengan NIM <b>$nim</b> tidak ditemukan.</p>";
    exit();
}

$mahasiswa = $result_mahasiswa->fetch_assoc();

// menyimpan metode pembayaran
function savePaymentMethod($conn, $id_pembayaran, $bank, $order_id) {
    // Cek apakah data sudah ada di tabel payment_midtrans
    $query_check = "SELECT * FROM payment_midtrans WHERE id_pembayaran = ?";
    $stmt_check = $conn->prepare($query_check);
    if (!$stmt_check) {
        die("Query gagal: " . $conn->error);
    }
    $stmt_check->bind_param('i', $id_pembayaran);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows === 0) {
        // Jika data belum ada, tambahkan ke tabel
        $query_insert = "INSERT INTO payment_midtrans (id_pembayaran, bank, order_id) VALUES (?, ?, ?)";
        $stmt_insert = $conn->prepare($query_insert);
        if (!$stmt_insert) {
            die("Query gagal: " . $conn->error);
        }
        $stmt_insert->bind_param('iss', $id_pembayaran, $bank, $order_id);

        if ($stmt_insert->execute()) {
            echo "Metode pembayaran berhasil disimpan.";
        } else {
            echo "Gagal menyimpan metode pembayaran: " . $conn->error;
        }
        $stmt_insert->close();
    } else {
        echo "Data metode pembayaran sudah ada.";
    }

    $stmt_check->close();
}


// Fungsi untuk mendapatkan detail transaksi
function getTransactionDetails($conn, $order_id) {
    $query = "SELECT p.*, pm.bank, pm.order_id 
              FROM pembayaran p 
              LEFT JOIN payment_midtrans pm 
              ON p.id_pembayaran = pm.id_pembayaran 
              WHERE p.nobayar = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Query gagal: " . $conn->error);
    }
    $stmt->bind_param('s', $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    return $result;
}

// var_dump($mahasiswa['id_mahasiswa']); // Tambahkan ini sebelum query
// Query untuk mengambil data transaksi 
$query_transaksi = "SELECT 
                        p.id_pembayaran, 
                        p.nobayar, 
                        p.jumlah, 
                        p.tglbayar, 
                        p.ket,  
                        COALESCE(pm.bank, '-') as bank, -- Tarik data bank
                        COALESCE(pm.order_id, '-') as order_id
                    FROM 
                        pembayaran p 
                    LEFT JOIN 
                        payment_midtrans pm 
                    ON 
                        p.id_pembayaran = pm.id_pembayaran
                    WHERE 
                        p.id_mahasiswa = ? 
                        AND p.nobayar IS NOT NULL
                    ORDER BY 
                        p.tglbayar DESC";
                  
$stmt_transaksi = $conn->prepare($query_transaksi);
if (!$stmt_transaksi) {
    die("Query gagal: " . $conn->error);
}
$stmt_transaksi->bind_param('i', $mahasiswa['id_mahasiswa']);
$stmt_transaksi->execute();
$result_transaksi = $stmt_transaksi->get_result();

$query_latest_transaction = "SELECT p.*, pm.bank, pm.order_id 
    FROM pembayaran p 
    LEFT JOIN payment_midtrans pm 
    ON p.id_pembayaran = pm.id_pembayaran 
    WHERE p.id_mahasiswa = ? 
    ORDER BY p.tglbayar DESC 
    LIMIT 1";

$stmt_latest = $conn->prepare($query_latest_transaction);
$stmt_latest->bind_param('i', $mahasiswa['id_mahasiswa']);
$stmt_latest->execute();
$result_latest = $stmt_latest->get_result();

$transaction = $result_latest->fetch_assoc();

?>


<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Transaksi</title>
    <link rel="stylesheet" href="../css/transaksi.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</head>

<body>
    <div class="container" id="receipt">
        <?php if (isset($transaction)): ?>
        <p>Transaksi Berhasil</p>
        <p class="" style="text-align: right;"><?php echo date('d-m-Y'); ?></p>
        <div class="header">
            <img src="../img/universitasbattuta.png" alt="">
            <div class="biaya">
                <td style="text-align: left;">Total Bayar</td>
                <td style="text-align: right;">Rp <?php echo number_format($transaction['jumlah'], 0, ',', '.'); ?></td>
            </div>

            <div class="details">
                <h3>Detail Penerima</h3>
                <div id="receiver-details" class="details-content01">
                    <table>
                        <tr>
                            <td>NIM</td>
                            <td style="text-align: right;"><?php echo htmlspecialchars($mahasiswa['nim']); ?></td>
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td style="text-align: right;"><?php echo htmlspecialchars($mahasiswa['nama']); ?></td>
                        </tr>
                        <?php if (array_key_exists('nama_jurusan', $mahasiswa)) { ?>
                        <tr>
                            <td>Jurusan</td>
                            <td style="text-align: right;"><?php echo htmlspecialchars($mahasiswa['nama_jurusan']); ?>
                            </td>
                        </tr>
                        <?php } ?>
                        <?php if (array_key_exists('nama_kelas', $mahasiswa)) { ?>
                        <tr>
                            <td>Fakultas</td>
                            <td style="text-align: right;"><?php echo htmlspecialchars($mahasiswa['nama_kelas']); ?>
                            </td>
                        </tr>
                        <?php } ?>
                    </table>
                </div>
            </div>

            <div class="details">
                <h3 onclick="toggleDetails('transaction-details')">Detail Transaksi</h3>
                <div id="transaction-details" class="details-content">
                    <table>
                        <tr>
                            <td>Metode Pembayaran</td>
                            <td style="text-align: right;"><?php echo htmlspecialchars($transaction['bank']); ?></td>
                        </tr>
                        <tr>
                            <td>ID Order</td>
                            <td style="text-align: right;"><?php echo htmlspecialchars($transaction['nobayar']); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="status"><?php echo htmlspecialchars($transaction['ket']); ?></div>
            <?php else: ?>
            <p>Transaksi tidak ditemukan.</p>
            <?php endif; ?>
        </div>

        <div class="footer">
            <p>Terima kasih telah melakukan pembayaran.</p>
            <p>Hubungi kami jika ada pertanyaan.</p>
            <p>Universitas Battuta</p>

            <div class="klik-button" style="display: flex; justify-content: center; gap: 10px;">
                <button onclick="kembaliBeranda()">Kembali</button>
                <button class="download" id="download-btn">Download</button>
                <button class="cetak" onclick="confirmPrint()">Bagikan</button>
            </div>
        </div>
    </div>
    <script>
    document.getElementById('download-btn').addEventListener('click', function() {
        const element = document.getElementById('receipt');
        html2canvas(element, {
            scale: 4, // Tingkatkan resolusi
            useCORS: true, // Dukung sumber eksternal
            scrollX: 0, // Pastikan tidak ada scroll
            scrollY: 0
        }).then(canvas => {
            const link = document.createElement('a');
            link.download = 'receipt.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
        });
    });
    </script>
    <script src="../js/transaksi.js"></script>
</body>

</html>