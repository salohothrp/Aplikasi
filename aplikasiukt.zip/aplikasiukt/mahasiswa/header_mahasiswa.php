<?php 
session_start();

if (!isset($_SESSION['nim']) || !isset($_SESSION['nama_mahasiswa'])) {
    session_destroy();
    header('location: loginauth.php');
    exit();
}

// Konfigurasi database
$host = 'localhost';
$user = 'root'; // Ganti jika username database Anda berbeda
$password = ''; // Ganti jika ada password untuk database Anda
$database = 'webpembayaranukt';

// Koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

// Cek koneksi
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

$nim = $_SESSION['nim'];

// Ambil bulan dan tahun saat ini
$bulan = date('m'); // Format: 01, 02, ...
$tahun = date('Y'); // Tahun saat ini

// Query untuk mengambil data mahasiswa berdasarkan NIM
// Query untuk mendapatkan informasi mahasiswa berdasarkan NIM
$query_mahasiswa = "SELECT m.*, a.nama_angkatan, j.nama_jurusan, k.nama_kelas 
                    FROM mahasiswa m
                    JOIN angkatan a ON m.id_angkatan = a.id_angkatan
                    JOIN jurusan j ON m.id_jurusan = j.id_jurusan
                    JOIN kelas k ON m.id_kelas = k.id_kelas
                    WHERE m.nim = ?";

$stmt_mahasiswa = $conn->prepare($query_mahasiswa);
$stmt_mahasiswa->bind_param('s', $nim);
$stmt_mahasiswa->execute();
$result_mahasiswa = $stmt_mahasiswa->get_result();

if ($result_mahasiswa->num_rows === 0) {
    echo "<p>Data mahasiswa dengan NIM <b>$nim</b> tidak ditemukan.</p>";
    exit();
}

$mahasiswa = $result_mahasiswa->fetch_assoc();
$id_mahasiswa = $mahasiswa['id_mahasiswa'];

// Fungsi untuk mendapatkan data pembayaran bulan depan
function getNextMonthPayment($conn, $id_mahasiswa) {
    $next_month = date('m', strtotime('+1 month'));
    $year = date('Y');
    
    if ($next_month == '01') {
        $year = date('Y', strtotime('+1 year'));
    }
    
    $query = "SELECT * FROM pembayaran 
              WHERE id_mahasiswa = ? 
              AND MONTH(jatuhtempo) = ? 
              AND YEAR(jatuhtempo) = ?";
     
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iii', $id_mahasiswa, $next_month, $year);
    $stmt->execute();
    return $stmt->get_result();
}

// Fungsi untuk menampilkan riwayat transaksi
function getTransactionHistory($conn, $id_mahasiswa) {
    $query = "SELECT * FROM pembayaran 
              WHERE id_mahasiswa = ? 
              AND nobayar IS NOT NULL 
              ORDER BY tglbayar DESC";
           
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id_mahasiswa);
    $stmt->execute();
    return $stmt->get_result();
}

// Ambil data pembayaran bulan depan  
$next_month_payments = getNextMonthPayment($conn, $id_mahasiswa);  
// Ambil riwayat transaksi
$result_riwayat = getTransactionHistory($conn, $id_mahasiswa);

// Query untuk mendapatkan data pembayaran berdasarkan id_mahasiswa dan filter per bulan
$query_pembayaran = "SELECT * FROM pembayaran 
                     WHERE id_mahasiswa = ? 
                     AND MONTH(jatuhtempo) = ? AND YEAR(jatuhtempo) = ?
                     ORDER BY jatuhtempo ASC";

$stmt_pembayaran = $conn->prepare($query_pembayaran);
$stmt_pembayaran->bind_param('iii', $id_mahasiswa, $bulan, $tahun);
$stmt_pembayaran->execute();
$result_pembayaran = $stmt_pembayaran->get_result();

// Query untuk mendapatkan riwayat transaksi
$query_riwayat = "SELECT * FROM pembayaran 
                  WHERE id_mahasiswa = ? 
                  AND nobayar IS NOT NULL 
                  ORDER BY tglbayar DESC";

$stmt_riwayat = $conn->prepare($query_riwayat);
$stmt_riwayat->bind_param('i', $id_mahasiswa);
$stmt_riwayat->execute();
$result_riwayat = $stmt_riwayat->get_result();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bayar UKT</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- midtrans -->
    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-6ZixioEWEmGnnFqz">
    </script>
    <link rel="stylesheet" href="../css/style_mahasiswa.css?v=1.0">
    <link rel="stylesheet" href="../css/riwayat_transaksi_mahasiswa.css?v=1.0">
    <!-- <script src="./script.js" defer></script> -->
    <style>

    </style>
</head>

<body>
    <nav>
        <div class="sidebar-header">
            <a class="logo-wrapper">
                <img src="../img/universitasbattuta.png" alt="Logo">
                <h2 class="hidden">BAYAR UKT</h2>
            </a>
            <button class="toggle-btn">
                <img src="../img/assets/expand.svg" alt="expand button">
            </button>
        </div>


        <div class="sidebar-links">
            <a class="link" onclick="showContent('dashboard')">
                <img src="../img/assets/home.svg" alt="">
                <span class="hidden">Home</span>
            </a>
            <a class="link" onclick="showContent('projects')">
                <img src="../img/assets/projects.svg" alt="">
                <span class="hidden">Projects</span>
            </a>
            <a class="link" onclick="showContent('transaksi')">
                <img src="../img/assets/money-flow.png" alt="">
                <span class="hidden">Transaksi</span>
            </a>
            </li>
            <a class="link" onclick="showContent('riwayatTransaksi')">
                <img src="../img/assets/duit.png" alt="">
                <span class="hidden">Riwayat Transaksi</span>
            </a>
        </div>


        <div class="sidebar-bottom">
            <div class="sidebar-links">
                <a class="link">
                    <img src="../img/assets/settings.svg" alt="">
                    <span class="hidden">Settings</span>
                </a>
            </div>

            <div class="user-profile" id="userProfileBtn">
                <div class="user-avatar">
                    <?php if(!empty($mahasiswa['foto'])): ?>
                    <img src="/aplikasiukt/uploads/<?= $mahasiswa['foto'] ?>" alt="">
                    <?php endif; ?>
                </div>
                <div class="user-details hidden">
                    <p class="username"><?php echo htmlspecialchars($_SESSION['nama_mahasiswa']); ?></p>
                    <p class="user-email"><?php echo htmlspecialchars($_SESSION['nim']); ?></p>
                </div>
                <div class="dropdown-content" id="profileDropdown" onclick="showContent('riwayatTransaksi')">
                    <a href="" class="dropdown-item">
                        <img src="../img/assets/profile.svg" alt="Profile">
                        <span>Profile</span>
                    </a>
                    <a href="../logout.php" class="dropdown-item1">
                        <img src="../img/assets/logout.svg" alt="logout">
                        <span>Logout</span>
                    </a>
                </div>

            </div>
        </div>
    </nav>
    <!-- Konten dashboard akan dimuat di sini -->
    <main class="content">
        <div id="dashboard-content" class="content-wrapper active">
            <h2>Selamat Datang
                <span><?php echo htmlspecialchars($_SESSION['nama_mahasiswa']); ?></span>
            </h2>
            <div class="card">
                <?php if(!empty($mahasiswa['foto'])): ?>
                <img src="/aplikasiukt/uploads/<?= $mahasiswa['foto'] ?>" alt="">
                <?php endif; ?>
                <div>
                    <?php
                        // Fungsi untuk mendapatkan class berdasarkan panjang nama
                        function getNameLengthClass($name) {                        
                            $length = strlen($name);
                            if ($length <= 5) return 'name-length-short';
                            if ($length <= 10) return 'name-length-medium';
                            return 'name-length-long';
                        }

                        // Fungsi untuk mendapatkan class berdasarkan huruf pertama
                        function getInitialClass($name) {                       
                                 $initial = strtolower(substr($name, 0, 1));
                                return 'initial-' . $initial;
                        }

                        // Dapatkan class-class yang diperlukan
                        $nameClasses = getNameLengthClass($_SESSION['nama_mahasiswa']) . ' ' . 
                                       getInitialClass($_SESSION['nama_mahasiswa']);
                        ?>

                    <!-- Gunakan class dalam elemen h2 -->
                    <h2 class="<?php echo htmlspecialchars($nameClasses); ?>">
                        <?php echo htmlspecialchars($_SESSION['nama_mahasiswa']); ?>
                    </h2>

                    <h3><?php echo htmlspecialchars($_SESSION['nim']); ?></h3>
                    <h3><?php echo htmlspecialchars($mahasiswa['nama_jurusan']); ?></h3>
                    <p>
                        Universitas Battuta Dipilih Karena Berkualitas!, Yuk Bayar Uang Kuliahmu dengan tepat waktu.
                        ingat ya!
                    </p>
                    <button class="shiny-cta" onclick="showContent('transaksi')"><span>Lihat Transaksi</span></button>
                    <button class="shiny-cta" onclick="showContent('riwayatTransaksi')"><span>Riwayat
                            Transaksi</span></button>
                    <button class="shiny-cta"><span>Follow Account</span></button>
                </div>
            </div>
        </div>

        <!-- Transaksi Content -->
        <div id="transaksi-content" class="content-wrapper">
            <h1>Transaksi Pembayaran Bulan <?php echo date('F Y'); ?></h1>
            <div class="biodata-section">
                <h3>Biodata Mahasiswa</h3>
                <table class="biodata-table">
                    <tr>
                        <td>NIM</td>
                        <td><strong><?php echo htmlspecialchars($_SESSION['nim']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><strong><?php echo htmlspecialchars($_SESSION['nama_mahasiswa']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Jurusan</td>
                        <td><strong><?php echo htmlspecialchars($mahasiswa['nama_jurusan']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Fakultas</td>
                        <td><strong><?php echo htmlspecialchars($mahasiswa['nama_kelas']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td><strong><?php echo htmlspecialchars($mahasiswa['nama_angkatan']); ?></strong></td>
                    </tr>
                </table>
            </div>
            <div class="transaksi">
                <h2>Detail Transaksi Pembayaran</h2>
                <?php if ($result_pembayaran->num_rows === 0): ?>
                <p>Belum ada transaksi yang tercatat untuk bulan ini.</p>
                <?php else: ?>
                <table class="transaksi-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Bulan</th>
                            <th>Jatuh Tempo</th>
                            <th>No Bayar</th>
                            <th>Tanggal Bayar</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                    $no = 1;
                    while ($row = $result_pembayaran->fetch_assoc()): 
                        $tanggal_bayar = $row['tglbayar'] ? date('d-m-Y', strtotime($row['tglbayar'])) : '-';
                        $jumlah_formatted = number_format($row['jumlah'], 0, ',', '.');
                    ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($row['bulan']); ?></td>
                            <td><?php echo date('d-m-Y', strtotime($row['jatuhtempo'])); ?></td>
                            <td><?php echo $row['nobayar'] ?: '-'; ?></td>
                            <td><?php echo $tanggal_bayar; ?></td>
                            <td>Rp <?php echo $jumlah_formatted; ?></td>
                            <td><?php echo $row['ket'] ?: '-'; ?></td>
                            <!-- Modifikasi bagian tombol Bayar pada tabel -->
                            <td>
                                <?php if (empty($row['nobayar'])): ?>
                                <!-- Tombol Bayar -->
                                <button onclick="payButton(
                                    '<?php echo $row['id_pembayaran']; ?>', 
                                    '<?php echo $nim; ?>', 
                                    <?php echo $row['jumlah']; ?>,
                                    '<?php echo htmlspecialchars($mahasiswa['nama']); ?>',
                                    '<?php echo htmlspecialchars($mahasiswa['nama_kelas']); ?>', 
                                    '<?php echo htmlspecialchars($mahasiswa['nama_angkatan']); ?>'
                                )" class="btn btn-primary btn-sm"
                                    href='proses_transaksi_mahasiswa.php?nim=<?= urlencode($nim) ?>&act=bayar&id=<?= $pembayaran['id_pembayaran'] ?>'>Bayar</button>

                                <?php else: ?>
                                <a class="btn btn-success btn-sm"
                                    href="transaksi.php?id_mahasiswa=<?php echo $id_mahasiswa; ?>">
                                    Transaksi
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>

        <div id="riwayatTransaksi-content" class="content-wrapper">
            <h1>Riwayat Transaksi</h1>
            <div class="biodata-section">
                <h3>Biodata Mahasiswa</h3>
                <table class="biodata-table">
                    <tr>
                        <td>NIM</td>
                        <td><strong><?php echo htmlspecialchars($mahasiswa['nim']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><strong><?php echo htmlspecialchars($_SESSION['nama_mahasiswa']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Jurusan</td>
                        <td><strong><?php echo htmlspecialchars($mahasiswa['nama_jurusan']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Fakultas</td>
                        <td><strong><?php echo htmlspecialchars($mahasiswa['nama_kelas']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td><strong><?php echo htmlspecialchars($mahasiswa['nama_angkatan']); ?></strong></td>
                    </tr>
                </table>
            </div>
            <div class="transaksi-section">
                <h2>Riwayat Transaksi</h2>
                <?php if ($result_riwayat->num_rows === 0): ?>
                <p>Belum ada riwayat transaksi yang tercatat.</p>
                <?php else: ?>
                <table class="riwayat-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Bulan</th>
                            <th>Tanggal Bayar</th>
                            <th>No Bayar</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        while ($row = $result_riwayat->fetch_assoc()): 
                            $tanggal_bayar = $row['tglbayar'] ? date('d-m-Y', strtotime($row['tglbayar'])) : '-';
                            $jumlah_formatted = number_format($row['jumlah'], 0, ',', '.');
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($row['bulan']); ?></td>
                            <td><?php echo $tanggal_bayar; ?></td>
                            <td><?php echo htmlspecialchars($row['nobayar']); ?></td>
                            <td>Rp <?php echo $jumlah_formatted; ?></td>
                            <td><?php echo htmlspecialchars($row['ket']) ?: '-'; ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <script src="../js/index_mahasiswa.js"></script>
</body>

</html>