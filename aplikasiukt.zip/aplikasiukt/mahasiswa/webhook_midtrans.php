<?php
header('Content-Type: application/json');

// Server Key Midtrans
$server_key = 'SB-Mid-server-Go3hUayddVcx8gj2VqyxeH31';

// Database connection
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'webpembayaranukt';

$conn = mysqli_connect($host, $user, $password, $database);
if (!$conn) {
    http_response_code(500);
    echo json_encode(['message' => 'Database connection failed']);
    exit();
}

// Get callback data
$callback = json_decode(file_get_contents('php://input'), true);

// Validate callback data
if (!$callback) {
    http_response_code(400);
    echo json_encode(['message' => 'Invalid JSON format']);
    exit();
}

$order_id = $callback['order_id'] ?? null;
$status_code = $callback['status_code'] ?? null;
$gross_amount = $callback['gross_amount'] ?? '0';
$input_signature_key = $callback['signature_key'] ?? null;

// Verify required fields
if (!$order_id || !$status_code || !$input_signature_key) {
    http_response_code(400);
    echo json_encode(['message' => 'Missing required fields']);
    exit();
}

// Verify signature
$generated_signature_key = hash("sha512", $order_id . $status_code . $gross_amount . $server_key);
if ($input_signature_key !== $generated_signature_key) {
    http_response_code(403);
    echo json_encode(['message' => 'Invalid signature']);
    exit();
}

// Get payment method
function getPaymentMethod($callback) {
    if (isset($callback['va_numbers'][0]['bank'])) {
        return strtoupper($callback['va_numbers'][0]['bank']);
    }
    
    if (isset($callback['payment_type'])) {
        switch ($callback['payment_type']) {
            case 'echannel':
                return 'MANDIRI';
            case 'bank_transfer':
                if (isset($callback['permata_va_number'])) return 'PERMATA';
                if (isset($callback['bca_va_number'])) return 'BCA';
                if (isset($callback['bni_va_number'])) return 'BNI';
                if (isset($callback['bri_va_number'])) return 'BRI';
                return 'BANK TRANSFER';
            case 'credit_card':
                return 'CREDIT CARD';
            default:
                return strtoupper($callback['payment_type']);
        }
    }
    return 'UNKNOWN';
}

// Process successful payment
if ($status_code == '200') {
    // Get payment details from pembayaran table
    $query = "SELECT id_pembayaran FROM pembayaran WHERE nobayar = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $payment = $result->fetch_assoc();
        $id_pembayaran = $payment['id_pembayaran'];
        $bank = getPaymentMethod($callback);
        
        // Begin transaction
        $conn->begin_transaction();
        
        try {
            // Update pembayaran status
            $update_payment = "UPDATE pembayaran SET ket = 'LUNAS', tglbayar = NOW() WHERE id_pembayaran = ?";
            $stmt = $conn->prepare($update_payment);
            $stmt->bind_param('i', $id_pembayaran);
            $stmt->execute();
            
            // Insert or update payment_midtrans
            $upsert_midtrans = "INSERT INTO payment_midtrans (id_pembayaran, bank, order_id) 
                               VALUES (?, ?, ?) 
                               ON DUPLICATE KEY UPDATE bank = VALUES(bank)";
            $stmt = $conn->prepare($upsert_midtrans);
            $stmt->bind_param('iss', $id_pembayaran, $bank, $order_id);
            $stmt->execute();
            
            $conn->commit();
            
            http_response_code(200);
            echo json_encode([
                'message' => 'Payment processed successfully',
                'order_id' => $order_id,
                'bank' => $bank
            ]);
        } catch (Exception $e) {
            $conn->rollback();
            http_response_code(500);
            echo json_encode(['message' => 'Transaction failed: ' . $e->getMessage()]);
        }
    } else {
        http_response_code(404);
        echo json_encode(['message' => 'Order not found']);
    }
} else {
    http_response_code(200);
    echo json_encode([
        'message' => 'Payment status received',
        'status_code' => $status_code
    ]);
}

$conn->close();
?>