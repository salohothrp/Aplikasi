<?php
session_start();
include 'koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id_admin'])) {
    header('location: loginauth.php');
    exit;
}

// Ambil ID pembayaran dari parameter GET
$id_pembayaran = isset($_GET['id_pembayaran']) ? $_GET['id_pembayaran'] : null;

if (!$id_pembayaran) {
    echo "<script>alert('ID Pembayaran tidak ditemukan!'); window.history.back();</script>";
    exit;
}

// Query untuk mengambil data pembayaran
$query = "SELECT 
            p.id_pembayaran, 
            m.nama AS nama_mahasiswa, 
            m.nim, 
            p.jumlah AS jumlah_pembayaran, 
            p.tglbayar AS tanggal_pembayaran, 
            a.nama_admin AS nama_admin 
          FROM pembayaran p
          JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
          JOIN admin a ON p.id_admin = a.id_admin
          WHERE p.id_pembayaran = '$id_pembayaran'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "<script>alert('Data pembayaran tidak ditemukan!'); window.history.back();</script>";
    exit;
}

$data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Slip Pembayaran</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
    }

    .slip-container {
        border: 1px solid #000;
        padding: 20px;
        width: 600px;
        margin: 0 auto;
    }

    .header {
        text-align: center;
        margin-bottom: 20px;
    }

    .header h1 {
        margin: 0;
        font-size: 24px;
    }

    .details {
        margin-bottom: 20px;
    }

    .details p {
        margin: 5px 0;
    }

    .footer {
        text-align: center;
        margin-top: 20px;
    }

    .footer p {
        margin: 0;
    }

    .print-button {
        text-align: center;
        margin-top: 20px;
    }

    .print-button button {
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
    }
    </style>
</head>

<body>
    <div class="slip-container">
        <div class="header">
            <h1>Slip Pembayaran</h1>
            <p>Universitas Battuta</p>
        </div>

        <div class="details">
            <p><strong>ID Pembayaran:</strong> <?= $data['id_pembayaran']; ?></p>
            <p><strong>Nama Mahasiswa:</strong> <?= $data['nama_mahasiswa']; ?></p>
            <p><strong>NIM:</strong> <?= $data['nim']; ?></p>
            <p><strong>Jumlah Pembayaran:</strong> Rp <?= number_format($data['jumlah_pembayaran'], 0, ',', '.'); ?></p>
            <p><strong>Tanggal Pembayaran:</strong> <?= date('d-m-Y', strtotime($data['tanggal_pembayaran'])); ?></p>
            <p><strong>Admin:</strong> <?= $data['nama_admin']; ?></p>
        </div>

        <div class="footer">
            <p>Terima kasih telah melakukan pembayaran.</p>
        </div>

        <div class="print-button">
            <button onclick="window.print()">Cetak</button>
        </div>
    </div>
</body>

</html>