<?php
$config = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'webpembayaranukt' // Ganti dengan nama database Anda
];

// Buat koneksi database global
$conn = new mysqli($config['host'], $config['username'], $config['password'], $config['database']);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set karakter encoding
$conn->set_charset("utf8");
?>