<?php 
session_start();
include 'header.php';
include 'koneksi.php'; ?>

<div class="card shadow mb-4 m-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary" style="font-size: 25px;">Cetak Data Laporan</h6>
    </div>
    <div class="card-body">
        <form action="cetak_laporan.php" method="get" target="_blank">
            <input type="date" name="awal" class="form-control mb-2">
            <input type="date" name="akhir" class="form-control mb-2">
            <button type="submit" class="btn btn-success" name="cetak">Cetak</button>
        </form>
    </div>
</div>
</div>
<?php include 'footer.php'; ?>