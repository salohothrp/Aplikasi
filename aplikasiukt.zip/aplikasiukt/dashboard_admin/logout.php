<?php 
session_start();
session_unset(); // Hapus semua sesi
session_destroy(); // Hapus sesi di server
header('location: loginauth.php');
?>