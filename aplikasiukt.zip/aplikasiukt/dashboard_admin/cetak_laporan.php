<?php
// Koneksi database
include 'koneksi.php';

// Validasi input tanggal
if (!isset($_GET['awal']) || !isset($_GET['akhir']) || empty($_GET['awal']) || empty($_GET['akhir'])) {
    die("Tanggal awal dan akhir harus diisi.");
}

$tanggal_awal = $_GET['awal'];
$tanggal_akhir = $_GET['akhir'];

// Query untuk mengambil data laporan berdasarkan rentang tanggal
$sql = "SELECT p.id_pembayaran, p.nobayar, p.tglbayar, p.jumlah, p.ket, m.nama AS nama_mahasiswa, m.nim 
        FROM pembayaran p
        JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
        WHERE p.tglbayar BETWEEN ? AND ?
        ORDER BY p.tglbayar ASC";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error pada prepare statement: " . $conn->error);
}
$stmt->bind_param("ss", $tanggal_awal, $tanggal_akhir);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pembayaran</title>
    <style>
    /* Gaya CSS sama seperti sebelumnya */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        position: relative;
    }

    .container {
        position: relative;
        width: 21cm;
        margin: 0 auto;
        padding: 1cm;
        z-index: 1;
        background-color: transparent;
    }

    /* .container::before {
        content: "";
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 600px;
        height: 600px;
        background-image: url('img/universitasbattuta.png');
        background-size: contain;
        background-repeat: no-repeat;
        opacity: 0.1;
        pointer-events: none;
        z-index: 1;
    } */

    .watermark {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 700px;
        height: 700px;
        background-image: url('img/universitasbattuta.png');
        background-size: contain;
        background-repeat: no-repeat;
        opacity: 0.1;
        pointer-events: none;
        z-index: -1;
    }

    .header {
        text-align: center;
        margin-bottom: 20px;
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
    }

    .logo {
        max-width: 100px;
        margin-bottom: 10px;
    }

    .header h1 {
        margin: 0;
        font-size: 24px;
        color: rgb(5, 141, 118);
        margin-bottom: 10px;
    }

    .header p {
        margin: 0;
        font-size: 18px;
        color: #666;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .table th,
    .table td {
        border: 1px solid #000;
        padding: 10px;
        text-align: left;
    }

    .table th {
        background-color: #f4f4f4;
    }

    /* .total {
        margin-top: 20px;
        text-align: right;
        font-weight: bold;
    }

    .tempat {
        display: flex;
        justify-content: right;
        margin-bottom: 5px;
        text-align: right;
        font-weight: bold;
    }

    .tempat-box {
        text-align: left;
        width: 200px;
    } */
    .total {
        margin-top: 20px;
        text-align: left;
        /* Ubah dari right ke left */
        font-weight: bold;
        color: rgb(5, 141, 118);
    }

    /* .tempat {
        display: flex;
        justify-content: left; */
    /* Ubah dari right ke left */
    /* margin-bottom: 5px;
        text-align: left;
        font-weight: bold;
    } */

    .tempat {
        text-align: left;
        margin-bottom: 0;
        /* Hapus jarak bawah */
    }

    .tempat p {
        margin: 0;
        /* Hapus margin pada paragraf */
        line-height: 1.2;
        /* Atur jarak baris */
    }

    .signature {
        display: flex;
        justify-content: left;
        /* Ubah dari right ke left */
        margin-top: 10px;
        padding: 0;
        width: 100%;
    }

    .signature-box {
        text-align: left;
        /* Tetap left untuk keselarasan */
        width: 200px;
    }


    .footer {
        text-align: center;
        margin-top: 40px;
        font-size: 14px;
    }

    /* .signature {
        display: flex;
        justify-content: right;
        margin-top: 10px;
        padding: 0;
        width: 100%;
    }

    .signature-box {
        text-align: left;
        width: 200px;
    } */

    @media print {
        body {
            margin: 0;
            padding: 0;
        }

        .watermark {
            position: fixed;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .container {
            width: 100%;
            padding: 0;
            margin: 0;
        }

        .no-print {
            display: none;
        }

        /* Pastikan semua elemen tetap terlihat saat dicetak */
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
    }
    </style>
</head>

<body>
    <div class="watermark"></div>
    <div class="container">
        <div class="header">
            <img src="img/universitasbattuta.png" alt="Logo Universitas Battuta" class="logo"
                onerror="this.style.display='none'">
            <h1>Laporan Pembayaran</h1>
            <p>Rentang Tanggal: <?= date('d-m-Y', strtotime($tanggal_awal)) ?> s/d
                <?= date('d-m-Y', strtotime($tanggal_akhir)) ?></p>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Pembayaran</th>
                    <th>Tanggal</th>
                    <th>Nama Mahasiswa</th>
                    <th>NIM</th>
                    <th>Jumlah (Rp)</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $no = 1;
                    $total = 0;
                    $nama_terakhir = ""; // Variabel untuk nama mahasiswa terakhir (digunakan di signature)
                    while ($row = $result->fetch_assoc()) {
                        $total += $row['jumlah'];
                        $nama_terakhir = $row['nama_mahasiswa']; // Simpan nama mahasiswa terakhir
                        $keterangan = ($row['ket'] === 'LUNAS') ? 'LUNAS' : 'BELUM LUNAS';
                        echo "<tr>
                                <td>{$no}</td>
                                <td>" . htmlspecialchars($row['nobayar']) . "</td>
                                <td>" . date('d-m-Y', strtotime($row['tglbayar'])) . "</td>
                                <td>" . htmlspecialchars($row['nama_mahasiswa']) . "</td>
                                <td>" . htmlspecialchars($row['nim']) . "</td>
                                <td style='text-align: right'>" . number_format($row['jumlah'], 0, ',', '.') . "</td>
                                <td>" . htmlspecialchars($keterangan) . "</td>
                            </tr>";
                        $no++;
                    }
                } else {
                    echo "<tr><td colspan='6' style='text-align: center;'>Tidak ada data pembayaran dalam rentang tanggal ini.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <div class="total">
            Total Pembayaran: Rp <?= isset($total) ? number_format($total, 0, ',', '.') : '0' ?>
        </div>

        <div class="tempat">
            <div class="tempat-box">
                <p>Medan , <?= date('d/m/y') ?> <br />
            </div>
        </div>
        <div class="signature">
            <!-- <div class="signature-box">
                <p>Petugas</p>
                <br><br><br>
                <p>________________</p>
                <p>Admin</p>
            </div> -->
            <!-- <div class="signature-box">
                <p>Mahasiswa</p>
                <br><br><br>
                <p>________________</p>
                <p><?= isset($nama_terakhir) ? htmlspecialchars($nama_terakhir) : "Tidak Ada Data" ?></p>
            </div> -->
            <div class="signature-box">
                <p>Petugas</p>
                <br><br><br>
                <p>________________</p>
                <p>Admin</p>
            </div>
        </div>

        <div class="footer">
            <p>Laporan ini dihasilkan secara otomatis oleh sistem.</p>
            <p>Universitas Battuta</p>
        </div>
    </div>

    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px; cursor: pointer;">
            Cetak Laporan
        </button>
    </div>
</body>

</html>