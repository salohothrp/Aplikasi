<?php 
session_start();
include 'koneksi.php'; 
include 'header.php';

if (isset($_GET['id_admin'])) {
    $id = $_GET['id_admin'];
    $query = "SELECT * FROM admin WHERE id_admin = '$id'";
    $exec = mysqli_query($conn, $query);

    if ($exec) {
        $res = mysqli_fetch_assoc($exec);
        if (!$res) {
            die("Data tidak ditemukan untuk ID Admin: $id");
        }
    } else {
        die("Query gagal: " . mysqli_error($conn));
    }
} else {
    die("ID Admin tidak disediakan.");
}

if(isset($_POST['simpan'])){
    $nama_admin = htmlentities(strip_tags(($_POST['nama_admin'])));
    $user_admin = htmlentities(strip_tags(($_POST['user_admin'])));
    $pass_admin = htmlentities(strip_tags(($_POST['pass_admin'])));
    $id_admin = $_POST['id_admin'];

    $query = "UPDATE admin 
            SET nama_admin = '$nama_admin', user_admin = '$user_admin', pass_admin = '$pass_admin'
            WHERE id_admin = '$id_admin'";


    $exec = mysqli_query($conn,$query);
    if($exec) {
        echo "<script>
        alert('data Admin berhasil diedit');
        document.location = 'index.php';
        </script>";
    }else {
        echo "<script>
        alert('data Admin gagal diedit');
        document.location = 'index.php';
        </script>";
    }
}


?>

<div class="bg-gradient-primary">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-x1-10 col-lg-12 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image">
                                <img width="100%" height="100%" src="img/salohot1.jpg" alt="">
                            </div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Edit Data Admin</h1>
                                    </div>
                                    <form class="user" action="" method="post">
                                        <div class="from-group mb-3">
                                            <input type="hidden" name="id_admin"
                                                value="<?php echo isset($res['id_admin']) ? htmlspecialchars($res['id_admin']) : ''; ?>">
                                            <input type="text" autocomplete="off" required name="nama_admin"
                                                class="form-control form-control-user" id="exampleFormControlInput1"
                                                aria-describedby="emailHelp" placeholder="Enter Name....."
                                                value="<?php echo isset($res['nama_admin']) ? htmlspecialchars($res['nama_admin']) : ''; ?>">
                                        </div>
                                        <div class="from-group mb-3">
                                            <input type="text" autocomplete="off" required name="user_admin"
                                                class="form-control form-control-user" id="exampleFormControlInput1"
                                                aria-describedby="emailHelp" placeholder="Enter Username....."
                                                value="<?php echo isset($res['user_admin']) ? htmlspecialchars($res['user_admin']) : ''; ?>">
                                        </div>
                                        <div class="from-group mb-3">
                                            <input type="password" autocomplete="off" required name="pass_admin"
                                                class="form-control form-control-user" id="exampleFormControlInput1"
                                                placeholder="Password"
                                                value="<?php echo isset($res['pass_admin']) ? htmlspecialchars($res['pass_admin']) : ''; ?>">
                                        </div>
                                        <button type="submit" name="simpan" class="btn btn-primary btn-user btn-block">
                                            Simpan
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>