<?php include 'koneksi.php';

if(isset($_POST['id_mahasiswa'])) {
    $id_mahasiswa = $_POST['id_mahasiswa'];
    $query = "SELECT mahasiswa.*, angkatan.*, jurusan.*, kelas.* FROM mahasiswa,angkatan,jurusan,kelas 
                WHERE mahasiswa.id_angkatan = angkatan.id_angkatan 
                AND mahasiswa.id_jurusan = jurusan.id_jurusan 
                AND mahasiswa.id_kelas = kelas.id_kelas 
                AND mahasiswa.id_mahasiswa = $id_mahasiswa";
        $exec = mysqli_query($conn, $query);
        $res = mysqli_fetch_assoc($exec);
        ?>


<form action="editdatamahasiswa.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id_mahasiswa" value="<?= $res['id_mahasiswa'] ?>">
    <input type="hidden" name="nim" value="<?= $res['nim'] ?>">

    <!-- Foto Section -->
    <div class="mb-3">
        <label class="form-label">Foto Saat Ini</label><br>
        <?php if(!empty($res['foto'])): ?>
        <img src="uploads/<?= $res['foto'] ?>" width="100" class="mb-2"><br>
        <?php endif; ?>
        <input type="file" name="foto" class="form-control" accept="image/*" style="padding: 3px 0; cursor: pointer;">
        <small class="text-muted">Biarkan jika anda tidak ingin mengubah foto</small>
    </div>

    <!-- NIM (Disabled) -->
    <div class="mb-3">
        <label class="form-label">NIM</label>
        <input type="text" class="form-control" value="<?= $res['nim'] ?>">
        <!-- disabled agar tidak bisa diubah jika ingin mengubah nim maka hilangkan disabled disamping value -->
    </div>

    <!-- Nama -->
    <div class="mb-3">
        <label class="form-label">Nama Mahasiswa</label>
        <input type="text" class="form-control" name="nama" value="<?= htmlspecialchars($res['nama']) ?>" required>
    </div>

    <!-- Angkatan -->
    <div class="mb-3">
        <label class="form-label">Angkatan</label>
        <select class="form-control" name="id_angkatan" required>
            <option value="">--Pilih Angkatan--</option>
            <?php
                $exec = mysqli_query($conn,"SELECT * FROM angkatan order by id_angkatan");
                while ($angkatan = mysqli_fetch_assoc($exec)):
                    $selected = ($res['id_angkatan'] == $angkatan['id_angkatan']) ? 'selected' : '';
            ?>
            <option value="<?= $angkatan['id_angkatan'] ?>" <?= $selected ?>>
                <?= htmlspecialchars($angkatan['nama_angkatan']) ?>
            </option>
            <?php endwhile; ?>
        </select>
    </div>

    <!-- Jurusan -->
    <div class="mb-3">
        <label class="form-label">Jurusan</label>
        <select class="form-control" name="id_jurusan" required>
            <option value="">--Pilih Jurusan--</option>
            <?php
                $exec = mysqli_query($conn,"SELECT * FROM jurusan order by id_jurusan");
                while ($jurusan = mysqli_fetch_assoc($exec)):
                    $selected = ($res['id_jurusan'] == $jurusan['id_jurusan']) ? 'selected' : '';
            ?>
            <option value="<?= $jurusan['id_jurusan'] ?>" <?= $selected ?>>
                <?= htmlspecialchars($jurusan['nama_jurusan']) ?>
            </option>
            <?php endwhile; ?>
        </select>
    </div>

    <!-- Fakultas -->
    <div class="mb-3">
        <label class="form-label">Fakultas</label>
        <select class="form-control" name="id_kelas" required>
            <option value="">--Pilih Fakultas--</option>
            <?php
                $exec = mysqli_query($conn,"SELECT * FROM kelas order by id_kelas");
                while ($kelas = mysqli_fetch_assoc($exec)):
                    $selected = ($res['id_kelas'] == $kelas['id_kelas']) ? 'selected' : '';
            ?>
            <option value="<?= $kelas['id_kelas'] ?>" <?= $selected ?>>
                <?= htmlspecialchars($kelas['nama_kelas']) ?>
            </option>
            <?php endwhile; ?>
        </select>
    </div>

    <!-- Alamat -->
    <div class="mb-3">
        <label class="form-label">Alamat</label>
        <textarea class="form-control" name="alamat" required><?= htmlspecialchars($res['alamat']) ?></textarea>
    </div>

    <!-- Footer Buttons -->
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="edit" class="btn btn-primary">Update</button>
    </div>
</form>

<?php 
}




// data kelas
if(isset($_POST['id_kelas'])) {
    $id_kelas = $_POST['id_kelas'];
    $exec = mysqli_query($conn,"SELECT * FROM  kelas WHERE id_kelas = '$id_kelas'");
    $res = mysqli_fetch_assoc($exec);
    ?>

<form action="editdatakelas.php" method="POST">
    <input type="hidden" name="id_kelas" value="<?= $res['id_kelas'] ?>">
    <input type="text" name="nama_kelas" class="form-control" value="<?= $res['nama_kelas'] ?>">
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="Submit" name="edit" class="btn btn-primary">Simpan</button>
    </div>
</form>

<!-- data jurusan -->
<?php }
if(isset($_POST['id_jurusan'])) {
    $id_jurusan = $_POST['id_jurusan'];
    $exec = mysqli_query($conn,"SELECT * FROM  jurusan WHERE id_jurusan = '$id_jurusan'");
    $res = mysqli_fetch_assoc($exec);
    ?>

<form action="editdatajurusan.php" method="POST">
    <input type="hidden" name="id_jurusan" value="<?= $res['id_jurusan'] ?>">
    <input type="text" name="nama_jurusan" class="form-control" value="<?= $res['nama_jurusan'] ?>">
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="Submit" name="edit" class="btn btn-primary">Simpan</button>
    </div>
</form>

<!-- data angkatan -->
<?php }
if(isset($_POST['id_angkatan'])) {
    $id_angkatan = $_POST['id_angkatan'];
    $exec = mysqli_query($conn,"SELECT * FROM  angkatan WHERE id_angkatan = '$id_angkatan'");
    $res = mysqli_fetch_assoc($exec);
    ?>

<form action="editdataangkatan.php" method="POST">
    <input type="hidden" name="id_angkatan" value="<?= $res['id_angkatan'] ?>">
    <input type="text" name="nama_angkatan" class="form-control mb-2" value="<?= $res['nama_angkatan'] ?>">
    <input type="text" name="biaya" class="form-control mb-2" value="<?= $res['biaya'] ?>">
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="Submit" name="edit" class="btn btn-primary">Simpan</button>
    </div>
</form>

<?php }

?>