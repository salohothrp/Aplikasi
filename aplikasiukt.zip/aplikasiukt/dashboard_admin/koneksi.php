<?php
// Cek apakah konstanta sudah didefinisikan sebelumnya
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_NAME')) define('DB_NAME', 'webpembayaranukt');

// Membuat koneksi
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek koneksi
if (!$conn) {
    throw new Exception("Database gagal terkoneksi: " . mysqli_connect_error(), 1);
}

// Set karakter encoding
mysqli_set_charset($conn, "utf8");
?>