<?php 
session_start();
include ('header.php'); 
include 'koneksi.php';

// menghapus data mahasiswa
if(isset($_GET['id_mahasiswa'])) {
    $id_mahasiswa = $_GET['id_mahasiswa'];
    
    // Ambil nama file foto sebelum menghapus data
    $query_foto = mysqli_query($conn, "SELECT foto FROM mahasiswa WHERE id_mahasiswa = '$id_mahasiswa'");
    $data_foto = mysqli_fetch_assoc($query_foto);
    
    if($data_foto) {
        $foto = $data_foto['foto'];
        $path_foto = 'uploads/' . $foto;
        
        // Hapus file foto jika ada
        if(file_exists($path_foto) && !empty($foto)) {
            unlink($path_foto);
        }
    }
    
    // Hapus data dari database
    $exec = mysqli_query($conn, "DELETE FROM mahasiswa WHERE id_mahasiswa = '$id_mahasiswa'");
    
    if($exec) {
        echo "<script>
        alert('Data mahasiswa berhasil dihapus');
        document.location = 'editdatamahasiswa.php';
        </script>";
    } else {
        echo "<script>
        alert('Data mahasiswa gagal dihapus');
        document.location = 'editdatamahasiswa.php';
        </script>";
    }
}
?>

<!-- button triger -->
<button class="btn btn-primary mb-3 m-3" data-bs-toggle="modal" data-bs-target="#exampleModal">Tambah Data</button>
<!-- button triger -->


<div class="card shadow mb-4 m-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary" style="font-size: 25px;">Data Mahasiswa/i</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr class="table-info">
                        <th>Foto</th>
                        <th>Nim</th>
                        <th>Nama Mahasiswa</th>
                        <th>Angkatan</th>
                        <th>Fakultas</th>
                        <th>Jurusan</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <?php
                
                // salah kode //
                // $query = "SELECT * FROM mahasiswa.*,angakatan.*,jurusan.*,kelas.* FROM mahasiswa,angakatan,jurusan,kelas WHERE mahasiswa.id_angkatan = angkatan.id_angkatan AND mahasiswa.id_jurusan = jurusan.id_jurusan AND mahasiswa.id_kelas = kelas.id_kelas ORDER BY  id_mahasiswa ";
                
                // Pemanggilan data dari tabel dengan id
                $query = "SELECT * FROM mahasiswa, angkatan, jurusan, kelas 
                          WHERE mahasiswa.id_angkatan = angkatan.id_angkatan 
                          AND mahasiswa.id_jurusan = jurusan.id_jurusan 
                          AND mahasiswa.id_kelas = kelas.id_kelas 
                          ORDER BY id_mahasiswa";
                $exec = mysqli_query($conn,$query);

                // salah kode //
                // if (!$exec) {
                //     die("Error pada query SQL: " . mysqli_error($conn));
                // }

                while($res = mysqli_fetch_assoc($exec)) :
                
                ?>
                <tbody>
                    <tr class="text-dark">
                        <td><img src="uploads/<?= $res['foto'] ?>" width="50" height="80" class="rounded" alt=""></td>
                        <td><?= $res['nim'] ?></td>
                        <td><?= $res['nama'] ?></td>
                        <td><?= $res['nama_angkatan'] ?></td>
                        <td><?= $res['nama_kelas'] ?></td>
                        <td><?= $res['nama_jurusan'] ?></td>
                        <td><?= $res['alamat'] ?></td>
                        <td>
                            <a href="editdatamahasiswa.php?id_mahasiswa=<?=  $res['id_mahasiswa'] ?>"
                                class=" btn btn-sm btn-danger mb-2"
                                onclick="return confirm('Apakah Yakin Ingin Menghapus Data?')">Hapus</a>
                            <a href="#" class="view_data btn btn-sm btn-warning mb-2" data-bs-toggle="modal"
                                data-bs-target="#myModal" id="<?php echo $res['id_mahasiswa'];?>">Edit</a>
                        </td>
                    </tr>
                    <?Php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"
                style=" background: linear-gradient(29deg, rgba(2, 0, 36, 1) 0%, rgba(9, 9, 121, 1) 27%, rgba(12, 30, 50, 1) 66%, rgba(7, 153, 182, 1) 100%); color: white;">
                <h5 class="modal-title" id="exampleModalLabel">Data Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
            </div>
            <div class="modal-body">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-2">
                        <label>Foto Mahasiswa</label>
                        <input type="file" name="foto" class="form-control" accept="image/*" required>
                    </div>
                    <input type="text" name="nama" placeholder="Nama Mahasiswa" class="form-control mb-2" required>
                    <select class="form-control mb-2" name="id_angkatan" required>
                        <option selected="">--Pilih Angkatan--</option>
                        <?php 
                            $exec = mysqli_query($conn,"SELECT * FROM angkatan order by id_angkatan");
                            while($angkatan = mysqli_fetch_assoc($exec)) :
                                echo "<option value=".$angkatan['id_angkatan'].">".$angkatan['nama_angkatan']."</option>";
                            endwhile;
                        ?>
                    </select>

                    <select class="form-control mb-2" name="id_jurusan" required>
                        <option selected="">--Pilih Jurusan--</option>
                        <?php 
                            $exec = mysqli_query($conn,"SELECT * FROM jurusan order by id_jurusan");
                            while($angkatan = mysqli_fetch_assoc($exec)) :
                                echo "<option value=".$angkatan['id_jurusan'].">".$angkatan['nama_jurusan']."</option>";
                            endwhile;
                        ?>
                    </select>

                    <select class="form-control mb-2" name="id_kelas" required>
                        <option selected="">--Pilih Fakultas--</option>
                        <?php 
                            $exec = mysqli_query($conn,"SELECT * FROM kelas order by id_kelas");
                            while($angkatan = mysqli_fetch_assoc($exec)) :
                                echo "<option value=".$angkatan['id_kelas'].">".$angkatan['nama_kelas']."</option>";
                            endwhile;
                        ?>
                    </select>

                    <textarea class="form-control mt-2" name="alamat" placeholder="Alamat Mahasiswa"></textarea>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="Submit" name="simpan" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit data mahasiswa -->
<div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style=" background: linear-gradient(29deg, rgba(2, 0, 36, 1) 0%, rgba(9, 9, 121, 1) 27%, rgba(12, 30, 50, 1) 66%, rgba(7, 153, 182, 1) 100%);
    color: white;">
                <h5 class="modal-title" id="exampleModalLabel">Edit Data Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
            </div>
            <div class="modal-body" id="datamahasiswa">

            </div>
        </div>
    </div>
</div>

<?php 
    if(isset($_POST['simpan'])) {
        try {

            // Validasi input
        if(empty($_POST['nama']) || empty($_POST['id_angkatan']) || 
        empty($_POST['id_jurusan']) || empty($_POST['id_kelas']) || 
        empty($_POST['alamat']) || empty($_FILES['foto'])) {
         throw new Exception("Semua field harus diisi!");
     }
        // Ambil data form
        $nama = htmlspecialchars(strip_tags(ucwords($_POST['nama'])));
        $id_angkatan = htmlspecialchars(strip_tags($_POST['id_angkatan']));
        $id_jurusan = htmlspecialchars(strip_tags($_POST['id_jurusan']));
        $id_kelas = htmlspecialchars(strip_tags($_POST['id_kelas']));
        $alamat = htmlspecialchars(strip_tags(ucwords($_POST['alamat'])));
        $nim = date('dmYHis');
        $password = "mahasiswa"; // Set password default

        // Proses upload foto
        $foto = $_FILES['foto']['name'];
        $foto_tmp = $_FILES['foto']['tmp_name'];
        $foto_ext = strtolower(pathinfo($foto, PATHINFO_EXTENSION));
        $allowed_ext = array('jpg', 'jpeg', 'png');
        
        if(!in_array($foto_ext, $allowed_ext)) {
            throw new Exception("Format file tidak didukung! Gunakan JPG, JPEG, atau PNG.");
        }

        $foto_name = $nim . '.' . $foto_ext;
        $upload_dir = 'uploads/';

        // Buat direktori jika belum ada
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Upload file
        if(!move_uploaded_file($foto_tmp, $upload_dir . $foto_name)) {
            throw new Exception("Gagal mengupload foto!");
        }

        // Query insert dengan password
        $query = "INSERT INTO mahasiswa (nim, nama, id_angkatan, id_jurusan, id_kelas, alamat, foto, password) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "ssssssss", $nim, $nama, $id_angkatan, $id_jurusan, $id_kelas, $alamat, $foto_name, $password);
        
        if(!mysqli_stmt_execute($stmt)) {
            throw new Exception("Gagal menyimpan data: " . mysqli_error($conn));
        }
            if($exec) {

            $bulanIndo =[
                '01' => 'Januari',
                '02' => 'Februari',
                '03' => 'Maret',
                '04' => 'April',
                '05' => 'Mei',
                '06' => 'Juni',
                '07' => 'Juli',
                '08' => 'Angustus',
                '09' => 'September',
                '10' => 'Oktober',
                '11' => 'November',
                '12' => 'Desember',
            ];
    
            $query = "SELECT mahasiswa.*, angkatan.* 
            FROM mahasiswa, angkatan
            WHERE mahasiswa.id_angkatan = angkatan.id_angkatan 
            ORDER BY mahasiswa.id_mahasiswa DESC LIMIT 1";
            
            $exec = mysqli_query($conn, $query);
            $res = mysqli_fetch_assoc($exec);

            if($res) {
                    $biaya = $res['biaya'];
                    $id_mahasiswa = $res['id_mahasiswa'];
                    $awaltempo = date('Y-m-d');

                for ($i=0; $i<36; $i++) {
                    $jatuhtempo = date("Y-m-d", strtotime("+$i month", strtotime($awaltempo)));
                    $bulan = $bulanIndo[date('m', strtotime($jatuhtempo))]." ".date('Y', strtotime($jatuhtempo));

                    $add = mysqli_query($conn, 
                    "INSERT INTO pembayaran (id_mahasiswa, jatuhtempo, bulan, jumlah) 
                        VALUES ('$id_mahasiswa', '$jatuhtempo', '$bulan', '$biaya')");
                }
            }

                echo "<script>
                    alert('Data mahasiswa berhasil disimpan');
                    document.location = 'editdatamahasiswa.php';
                    </script>";
            } else {
                throw new Exception(mysqli_error($conn));
            }

            } catch (Exception $e) {
            echo "<script>
                alert('Gagal menyimpan data: " . $e->getMessage() . "');
                </script>";
        }

    }


?>

<?php include ('footer.php'); ?>

<!-- mengambil data dari mahasiswa dan mengedit data mahasiswa -->
<script type="text/javascript">
$('.view_data').click(function() {
    var id_mahasiswa = $(this).attr('id');
    $.ajax({
        url: 'view.php',
        method: 'post',
        data: {
            id_mahasiswa: id_mahasiswa
        },
        success: function(data) {
            $('#datamahasiswa').html(data)
            $('#myModal').modal('show');
        }
    })
})
</script>


<!-- mengedit data mahasiswa -->
<?php 
if(isset($_POST['edit'])) {
    try {
        // Ambil data dari form
        $id_mahasiswa = $_POST['id_mahasiswa'];
        $nim = htmlspecialchars(strip_tags($_POST['nim']));
        $nama = htmlspecialchars(strip_tags(ucwords($_POST['nama'])));
        $id_angkatan = htmlspecialchars(strip_tags($_POST['id_angkatan']));
        $id_jurusan = htmlspecialchars(strip_tags($_POST['id_jurusan']));
        $id_kelas = htmlspecialchars(strip_tags($_POST['id_kelas']));
        $alamat = htmlspecialchars(strip_tags(ucwords($_POST['alamat'])));

        // Mulai query update
        $query_update = "UPDATE mahasiswa SET 
                        nim = '$nim', 
                        nama = '$nama',  
                        id_angkatan = '$id_angkatan', 
                        id_jurusan = '$id_jurusan',
                        id_kelas = '$id_kelas', 
                        alamat = '$alamat'";

        // Cek apakah ada foto baru diupload
        if(!empty($_FILES['foto']['name'])) {
            // Validasi format file
            $allowed_types = array('jpg', 'jpeg', 'png');
            $foto = $_FILES['foto']['name'];
            $foto_tmp = $_FILES['foto']['tmp_name'];
            $foto_ext = strtolower(pathinfo($foto, PATHINFO_EXTENSION));

            if(!in_array($foto_ext, $allowed_types)) {
                throw new Exception("Format file tidak didukung! Gunakan JPG, JPEG, atau PNG.");
            }

            // Generate nama file baru
            $foto_name = $nim . '.' . $foto_ext;
            $upload_dir = 'uploads/';

            // Hapus foto lama jika ada
            $query_foto_lama = mysqli_query($conn, "SELECT foto FROM mahasiswa WHERE id_mahasiswa = '$id_mahasiswa'");
            $data_foto_lama = mysqli_fetch_assoc($query_foto_lama);
            
            if($data_foto_lama && !empty($data_foto_lama['foto'])) {
                $path_foto_lama = $upload_dir . $data_foto_lama['foto'];
                if(file_exists($path_foto_lama)) {
                    unlink($path_foto_lama);
                }
            }

            // Upload foto baru
            if(!move_uploaded_file($foto_tmp, $upload_dir . $foto_name)) {
                throw new Exception("Gagal mengupload foto baru!");
            }

            // Tambahkan update foto ke query
            $query_update .= ", foto = '$foto_name'";
        }

        // Selesaikan query update
        $query_update .= " WHERE id_mahasiswa = '$id_mahasiswa'";

        // Eksekusi query update
        $exec = mysqli_query($conn, $query_update);
        
        if($exec) {
            echo "<script>
            alert('Data mahasiswa berhasil diupdate');
            document.location = 'editdatamahasiswa.php';
            </script>";
        } else {
            throw new Exception(mysqli_error($conn));
        }

    } catch (Exception $e) {
        echo "<script>
        alert('Gagal mengupdate data: " . $e->getMessage() . "');
        document.location = 'editdatamahasiswa.php';
        </script>";
    }
}

?>