<?php 
session_start();
include 'koneksi.php';
include 'header.php';
?>
<style>
.alert {
    width: 80%;
    margin: 90px;
    text-align: center;
    font-size: 1.5em;
    background: linear-gradient(29deg, rgba(2, 0, 36, 1) 0%, rgba(9, 9, 121, 1) 27%, rgba(12, 30, 50, 1) 66%, rgba(7, 153, 182, 1) 100%);
    color: white;
}

.card-header {
    background: linear-gradient(29deg, rgba(2, 0, 36, 1) 0%, rgba(9, 9, 121, 1) 27%, rgba(12, 30, 50, 1) 66%, rgba(7, 153, 182, 1) 100%);
    color: white;
}

.rainbow-text {
    display: inline-block;
    animation: rainbow 2s linear infinite;
}

@keyframes rainbow {
    0% {
        color: red;
    }

    14% {
        color: orange;
    }

    28% {
        color: yellow;
    }

    42% {
        color: green;
    }

    57% {
        color: blue;
    }

    71% {
        color: indigo;
    }

    85% {
        color: violet;
    }

    100% {
        color: red;
    }
}
</style>

<div class="card shadow mb-4 m-3">
    <div class="card-body">
        <form action="" method="get">
            <table class="table">
                <tr>
                    <td>NIM</td>
                    <td>:</td>
                    <td>
                        <input type="text" name="nim" placeholder="Masukkan Nim Mahasiswa" class="form-control"
                            value="<?= isset($_GET['nim']) ? htmlspecialchars($_GET['nim']) : '' ?>">
                    </td>
                    <td><button type="submit" class="btn btn-primary" name="cari">Search</button></td>
                </tr>
            </table>
        </form>
    </div>
</div>

<?php 
if(isset($_GET['nim']) && $_GET['nim'] != ''){
    // Sanitasi input
    $nim = mysqli_real_escape_string($conn, $_GET['nim']);
    
    // Gunakan prepared statement
    $query = "SELECT m.*, a.*, j.*, k.* 
              FROM mahasiswa m
              JOIN angkatan a ON m.id_angkatan = a.id_angkatan 
              JOIN jurusan j ON m.id_jurusan = j.id_jurusan
              JOIN kelas k ON m.id_kelas = k.id_kelas
              WHERE m.nim = ?";
              
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $nim);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $mahasiswa = mysqli_fetch_assoc($result);
        $id_mahasiswa = $mahasiswa['id_mahasiswa'];
    } else {
        echo "<div class='alert'>Data mahasiswa dengan NIM <b class='rainbow-text'>" . htmlspecialchars($nim) . "</b> tidak ditemukan.</div>";
        include 'footer.php';
        exit;
    }
    ?>

<!-- Panel Biodata -->
<div class="card shadow mb-4 m-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold">Biodata Mahasiswa</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <tr>
                    <td>NIM</td>
                    <td><?= htmlspecialchars($mahasiswa['nim']) ?></td>
                </tr>
                <tr>
                    <td>Nama Mahasiswa</td>
                    <td><?= htmlspecialchars($mahasiswa['nama']) ?></td>
                </tr>
                <tr>
                    <td>Fakultas</td>
                    <td><?= htmlspecialchars($mahasiswa['nama_kelas']) ?></td>
                </tr>
                <tr>
                    <td>Tahun Ajaran</td>
                    <td><?= htmlspecialchars($mahasiswa['nama_angkatan']) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>

<!-- Panel Pembayaran -->
<div class="card shadow mb-4 m-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold">Data Pembayaran</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>Bulan</th>
                        <th>Jatuh Tempo</th>
                        <th>No Bayar</th>
                        <th>Tanggal Bayar</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $query_pembayaran = "SELECT * FROM pembayaran WHERE id_mahasiswa = ? ORDER BY jatuhtempo ASC";
                        $stmt_pembayaran = mysqli_prepare($conn, $query_pembayaran);
                        mysqli_stmt_bind_param($stmt_pembayaran, "i", $id_mahasiswa);
                        mysqli_stmt_execute($stmt_pembayaran);
                        $result_pembayaran = mysqli_stmt_get_result($stmt_pembayaran);
                        
                        $no = 1;
                        while($pembayaran = mysqli_fetch_assoc($result_pembayaran)) { 
                            $tanggal_bayar = !empty($pembayaran['tglbayar']) ? date('d-m-Y', strtotime($pembayaran['tglbayar'])) : '-';
                            $jumlah_formatted = number_format($pembayaran['jumlah'], 0, ',', '.');
                            ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($pembayaran['bulan']) ?></td>
                        <td><?= date('d-m-Y', strtotime($pembayaran['jatuhtempo'])) ?></td>
                        <td><?= htmlspecialchars($pembayaran['nobayar']) ?></td>
                        <td><?= $tanggal_bayar ?></td>
                        <td>Rp <?= $jumlah_formatted ?></td>
                        <td><?= htmlspecialchars($pembayaran['ket']) ?></td>
                        <td>
                            <?php if(empty($pembayaran['nobayar'])): ?>
                            <a class='btn btn-primary btn-sm'
                                href='proses_transaksi.php?nim=<?= urlencode($nim) ?>&act=bayar&id=<?= $pembayaran['id_pembayaran'] ?>'>
                                Bayar
                            </a>
                            <?php else: ?>
                            <a class='btn btn-primary btn-sm'
                                href='proses_transaksi.php?nim=<?= urlencode($nim) ?>&act=batal&id=<?= $pembayaran['id_pembayaran'] ?>'>
                                Batal
                            </a>
                            <a class='btn btn-success btn-sm'
                                href='cetak_slip_pembayaran.php?id_pembayaran=<?= $pembayaran['id_pembayaran'] ?>'
                                target='_blank'>
                                Cetak
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php include 'footer.php'; ?>
<?php } ?>