<?php
//biar tidak bisa kembali dengan tombol browser "kembali"
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


session_start();
include 'koneksi.php';

// Cek jika sudah login
if (isset($_SESSION['user_type'])) {
    if ($_SESSION['user_type'] === 'admin') {
        header('location: index.php'); //dasboard admin
    } elseif ($_SESSION['user_type'] === 'mahasiswa') {
        header('location: mahasiswa/mahasiswa_dasboard.php'); // dasboard mahasiswa
        exit();
    }
}

if(isset($_POST['login'])) {
    // Pastikan semua field ada dan tidak kosong
    if (empty($_POST['user']) || empty($_POST['pass'])) {
        $error = "Username dan password harus diisi!";
    } else {
        $username = htmlspecialchars(strip_tags($_POST['user']));
        $password = htmlspecialchars(strip_tags($_POST['pass']));
        
        // Coba login sebagai admin dulu
        $query = "SELECT * FROM admin WHERE user_admin = ? AND pass_admin = ?";
        $stmt = mysqli_prepare($conn, $query);
        
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ss", $username, $password);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if(mysqli_num_rows($result) > 0) {
                $user = mysqli_fetch_assoc($result);

                //set data sesi untuk admin
                $_SESSION['user_type'] = 'admin';
                $_SESSION['id_admin'] = $user['id_admin'];
                $_SESSION['nama_admin'] = $user['nama_admin'];
                header('location: index.php'); //ke dasboard admin
                exit();
            }
            mysqli_stmt_close($stmt);
            
            // Jika bukan admin, coba login sebagai mahasiswa
            $query = "SELECT * FROM mahasiswa WHERE nim = ? AND password = ?";
            $stmt = mysqli_prepare($conn, $query);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "ss", $username, $password);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
            
                if (mysqli_num_rows($result) > 0) {
                    $user = mysqli_fetch_assoc($result);
                    $_SESSION['user_type'] = 'mahasiswa';
                    $_SESSION['nim'] = $user['nim'];
                    $_SESSION['nama_mahasiswa'] = $user['nama'];
                    
                     // Add error handling
                    if (!headers_sent()) {
                        header('location: mahasiswa/header_mahasiswa.php');
                    } else {
                        echo '<script>window.location.href="mahasiswa/header_mahasiswa.php";</script>';
                    }
                    exit();
                }
                mysqli_stmt_close($stmt);
            }
            
            $error = "Username atau password salah!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Sistem UKT</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/style.css?v=1.0">
    <link rel="stylesheet" href="css/liquid-background.css?v=1.0">
    <script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>
</head>

<body>
    <div class="bouncing-blobs-container">
        <div class="bouncing-blobs-glass"></div>
        <div class="bouncing-blobs">
            <div class="bouncing-blob bouncing-blob--blue"></div>
            <div class="bouncing-blob bouncing-blob--blue"></div>
            <div class="bouncing-blob bouncing-blob--blue"></div>
            <div class="bouncing-blob bouncing-blob--white"></div>
            <div class="bouncing-blob bouncing-blob--purple"></div>
            <div class="bouncing-blob bouncing-blob--purple"></div>
            <div class="bouncing-blob bouncing-blob--pink"></div>
        </div>
    </div>
    <div class="container">
        <div class="curved-shape"></div>
        <div class="curved-shape2"></div>
        <div class="form-box Login">
            <h2 class="animation" style="--D:0 --S:10;">Login Sistem UKT</h2>
            <?php if(isset($error)): ?>
            <div class="alert alert-danger animation" style="--D:0 --S:10;">
                <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>
            <form action="" method="post">
                <div class="input-box animation" style="--D:1; --S:11;">
                    <input type="text" required name="user">
                    <label>Username/NIM</label>
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-box animation" style="--D:2; --S:12;">
                    <input type="password" required name="pass">
                    <label>Password</label>
                    <i class='bx bxs-lock-alt'></i>
                </div>
                <div class="input-box animation" style="--D:3; --S:13;">
                    <button class="btn" type="submit" name="login">Login</button>
                </div>
                <div class="regi-link animation" style="--D:4; --S:14;">
                    <p>Don't have an account ? <a href="#" class="SignUpLink">Sign Up</a></p>
                </div>
            </form>
        </div>
        <div class="info-content Login">
            <h2 class="animation" style="--D:0; --S:10;">SELAMAT DATANG!</h2>
            <P class="animation" style="--D:1;--S:11;">Sistem Informasi Pembayaran UKT</P>
        </div>
        <!-- <div class="regi-link animation" style="--D:4; --S:14;">
                    <p>Don't have an account ? <a href="#" class="SignUpLink">Sign Up</a></p>
                </div> -->
        <!-- bagian sign up -->
        <div class="form-box Register">
            <h2 class="animation" style="--li:17; --S:0;">Registrasi</h2>
            <form action="loginauth.php" method="post">
                <div class="input-box animation" style="--li:18; --S:1;">
                    <input type="text" required name="user">
                    <label for="">Username</label>
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-box animation" style="--li:19; --S:2;">
                    <input type="text" required name="user">
                    <label for="">Password</label>
                    <i class='bx bxs-lock-alt'></i>
                </div>
                <div class="input-box animation" style="--li:20; --S:3;">
                    <button class="btn" type="submit">Registrasi</button>
                </div>
                <div class="regi-link animation" style="--li:21; --S:4;">
                    <p>Don't have an account ? <a href="#" class="SignInLink">Sign in</a></p>
                </div>
            </form>
        </div>
        <div class="info-content Register">
            <h2 class="animation" style="--li:17; --S:0;">WELCOME BACK!</h2>
            <P class="animation" style="--li:18; --S:1;">Silahkan Daftarkan akun anda dengan Username dan Password </P>
        </div>
    </div>
    <script>

    </script>
    <script src="js/index.js"></script>
    <script src="js/liquid-background.js"></script>
</body>

</html>