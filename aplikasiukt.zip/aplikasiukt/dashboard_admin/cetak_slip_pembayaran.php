<?php
// cetak_slip_pembayaran.php

// Koneksi database
include 'koneksi.php';

// Validasi input
if (!isset($_GET['id_pembayaran']) || empty($_GET['id_pembayaran'])) {
    die("ID Pembayaran tidak valid");
}

$id_pembayaran = (int)$_GET['id_pembayaran'];

// Query untuk mengambil data pembayaran
$sql = "SELECT p.*, m.nama as nama_mahasiswa, m.nim 
        FROM pembayaran p
        JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
        WHERE p.id_pembayaran = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id_pembayaran);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);
} else {
    die("Data pembayaran tidak ditemukan");
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Slip Pembayaran</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
    }

    .slip-container {
        width: 21cm;
        /* min-height: 29.7cm; */
        padding: 1cm;
        margin: 0 auto;
        background: white;
    }

    .header {
        text-align: center;
        margin-bottom: 20px;
        border-bottom: 2px solid #000;
        padding-bottom: 20px;
    }

    .header h1 {
        margin: 0;
        font-size: 24px;
        color: rgb(5, 141, 118);
        margin-bottom: 10px;
    }

    .header p {
        margin: 0;
        font-size: 24px;
        color: #000000;
        margin-top: 0;
    }

    .logo {
        max-width: 100px;
        margin-bottom: 10px;
    }

    .info {
        margin-bottom: 30px;
    }

    .info table {
        width: 100%;
        border: none;
    }

    .info td {
        padding: 5px;
        vertical-align: top;
    }

    .payment-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
    }

    .payment-table th,
    .payment-table td {
        border: 1px solid #000;
        padding: 10px;
    }

    .total {
        text-align: right;
        margin: 20px 0;
        font-weight: bold;
    }

    .footer {
        margin-top: 50px;
        text-align: center;
    }

    .signature {
        margin-top: 50px;
        display: flex;
        justify-content: space-between;
        width: 100%;
    }

    .signature-box {
        text-align: center;
        width: 200px;
    }

    .payment-info {
        margin: 0 auto;
        text-align: left;
        font-size: 14px;
        padding-top: 50px;
        margin-top: 55px;
    }

    .payment-info h3 {
        margin: 0;
        font-size: 24px;
        color: rgb(5, 141, 118);
        margin-bottom: 10px;
    }

    @media print {
        @page {
            size: A4;
            margin: 0;
        }

        body {
            margin: 0;
            padding: 0;
        }

        .no-print {
            display: none;
        }

    }

    /* .card-header {
        background: rgb(5, 141, 118);
        color: white;
    } */
    </style>
</head>

<body>
    <div class="slip-container">
        <div class="header">
            <img src="img/universitasbattuta.png" alt="Logo" class="logo" onerror="this.style.display='none'">
            <h1>SLIP PEMBAYARAN UKT</h1>
            <p class="kampus">Universitas Battuta</p>
        </div>

        <div class="info">
            <table>
                <tr>
                    <td width="200">Nomor Pembayaran</td>
                    <td>:</td>
                    <td><?= htmlspecialchars($data['nobayar']) ?></td>
                </tr>
                <tr>
                    <td>Tanggal</td>
                    <td>:</td>
                    <td><?= date('d F Y', strtotime($data['tglbayar'])) ?></td>
                </tr>
                <tr>
                    <td>Nama Mahasiswa</td>
                    <td>:</td>
                    <td><?= htmlspecialchars($data['nama_mahasiswa']) ?></td>
                </tr>
                <tr>
                    <td>NIM</td>
                    <td>:</td>
                    <td><?= htmlspecialchars($data['nim']) ?></td>
                </tr>
            </table>
        </div>

        <table class="payment-table">
            <thead class="card-header">
                <tr>
                    <th>No</th>
                    <th>Keterangan</th>
                    <th>Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Pembayaran UKT <?= htmlspecialchars($data['bulan']) ?></td>
                    <td style="text-align: right">Rp <?= number_format($data['jumlah'], 0, ',', '.') ?></td>
                </tr>
            </tbody>
        </table>

        <div class="total">
            Total Pembayaran: Rp <?= number_format($data['jumlah'], 0, ',', '.') ?>
        </div>

        <div class="footer">
            <p>Slip ini merupakan bukti pembayaran yang sah</p>
            <p>Terima kasih atas pembayaran Anda</p>
        </div>

        <div class="signature">
            <div class="signature-box">
                <p>Petugas</p>
                <br><br><br>
                <p>________________</p>
                <p>Admin</p>
            </div>
            <div class="signature-box">
                <p>Mahasiswa</p>
                <br><br><br>
                <p>________________</p>
                <p><?= htmlspecialchars($data['nama_mahasiswa']) ?></p>
            </div>
        </div>
        <div class="payment-info">
            <h3>Payment Information</h3>
            <p><strong>Metode Pembayaran:</strong> Transfer Bank</p>
            <p><strong>Bank:</strong> Bank Mandiri</p>
            <p><strong>No. Rekening:</strong> 123-456-7890</p>
            <p><strong>Atas Nama:</strong> Universitas XYZ</p>
            <p><strong>Keterangan:</strong> Pembayaran UKT Semester Genap</p>
        </div>
    </div>



    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px; cursor: pointer;">
            Cetak Slip
        </button>
    </div>
</body>

</html>